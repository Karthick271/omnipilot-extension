// background.js (MV3, type: module)

// 1) Side panel: open when the toolbar icon is clicked (handled by Chrome)
//    No chrome.action.onClicked — avoids 'onClicked of undefined' crash.
chrome.runtime.onInstalled.addListener(async () => {
  if (chrome.sidePanel?.setPanelBehavior) {
    try {
      await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    } catch (e) {
      console.warn('setPanelBehavior failed:', e);
    }
  }
});

// 2) Keyboard shortcut (Alt+P): open side panel for current tab
chrome.commands?.onCommand?.addListener(async (cmd) => {
  if (cmd !== 'toggle-panel' || !chrome.sidePanel?.open) return;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) await chrome.sidePanel.open({ tabId: tab.id });
  } catch (e) {
    console.warn('toggle-panel failed:', e);
  }
});

// 3) Context menu: save highlighted text → "Pins"
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus?.create?.({
    id: 'chatpilot-save-selection',
    title: 'Save selection to ChatPilot → Pins',
    contexts: ['selection'],
  });
});

chrome.contextMenus?.onClicked?.addListener?.(async (info, tab) => {
  try {
    if (info.menuItemId !== 'chatpilot-save-selection' || !info.selectionText) return;
    const key = 'chatpilot/pins';
    const { [key]: pins = [] } = await chrome.storage.local.get(key);
    pins.push({ text: info.selectionText, url: info.pageUrl, ts: Date.now() });
    await chrome.storage.local.set({ [key]: pins });

    // Optional toast (requires "notifications" permission to be useful)
    chrome.notifications?.create?.({
      type: 'basic',
      iconUrl: 'icons/icon-48.png',
      title: 'Pinned to ChatPilot',
      message: String(info.selectionText).slice(0, 120),
    });
  } catch (e) {
    console.warn('contextMenus.onClicked error:', e);
  }
});

// 4) Offscreen clipboard helper ------------------------------------------------
async function ensureOffscreen() {
  try {
    const hasDoc = await chrome.offscreen?.hasDocument?.();
    if (!hasDoc) {
      await chrome.offscreen?.createDocument?.({
        url: 'offscreen.html',
        reasons: ['CLIPBOARD'],
        justification: 'Write to clipboard from extension UI (panel iframe)',
      });
    }
  } catch (e) {
    // harmless if already exists
    console.debug('ensureOffscreen create', e?.message || e);
  }

  // Wait until offscreen script is listening
  for (let i = 0; i < 10; i++) {
    try {
      const pong = await new Promise((resolve) => {
        try {
          chrome.runtime.sendMessage({ type: 'OFFSCREEN_PING' }, (resp) => resolve(resp));
        } catch {
          resolve(null);
        }
      });
      if (pong && pong.ok) return true;
    } catch {}
    await new Promise((r) => setTimeout(r, 50));
  }
  return true;
}

// 5) Messages: COPY_TO_CLIPBOARD via offscreen
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'COPY_TO_CLIPBOARD') {
    (async () => {
      try {
        await ensureOffscreen();
        chrome.runtime.sendMessage(
          { type: 'OFFSCREEN_COPY', text: msg.text },
          (resp) => {
            const err = chrome.runtime.lastError;
            if (err) return sendResponse({ ok: false, error: String(err.message || err) });
            sendResponse(resp || { ok: false });
          },
        );
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true; // async
  }
});

// 6) Messages: robust INSERT_TEXT into page (ChatGPT/Claude textareas, etc.)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'INSERT_TEXT') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) return sendResponse({ ok: false, error: 'No active tab' });

        const text = msg.text || '';
        const [{ result } = {}] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: 'MAIN',
          func: (inText) => {
            // Deep scan across shadow roots
            function* allNodes(root = document) {
              const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
              yield root;
              let n;
              while ((n = walker.nextNode())) {
                yield n;
                if (n.shadowRoot) yield* allNodes(n.shadowRoot);
              }
            }
            function findInput() {
              const sels = [
                '#prompt-textarea', 'textarea#prompt-textarea',
                'textarea[placeholder*="Message"]', 'form textarea',
                '[role="textbox"]', 'div[contenteditable="true"]', 'textarea',
              ];
              for (const s of sels) { const el = document.querySelector(s); if (el) return el; }
              for (const el of allNodes()) {
                if (el.matches?.('[role="textbox"],textarea,div[contenteditable="true"]')) return el;
              }
              return null;
            }
            const el = findInput();
            if (!el) return { ok: false, error: 'Input not found' };

            if (el.tagName === 'TEXTAREA' || 'value' in el) {
              const desc = Object.getOwnPropertyDescriptor(el.__proto__ || {}, 'value');
              if (desc?.set) desc.set.call(el, inText); else el.value = inText;
              el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true }));
              try { el.setSelectionRange?.(inText.length, inText.length); } catch {}
              el.dispatchEvent(new Event('change', { bubbles: true, composed: true }));
            } else {
              el.focus();
              el.textContent = inText;
              el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, data: inText }));
            }
            el.scrollIntoView?.({ behavior: 'smooth', block: 'center' });
            return { ok: true };
          },
          args: [text],
        });

        sendResponse(result || { ok: false });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true; // async
  }
});

// 7) Messages: COPY_VIA_PAGE (try navigator.clipboard on page)
//    Useful fallback when offscreen is blocked.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'COPY_VIA_PAGE') {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) return sendResponse({ ok: false, error: 'No active tab' });

        const text = msg.text || '';
        const [{ result } = {}] = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: 'MAIN',
          func: (txt) => {
            try {
              if (navigator.clipboard?.writeText) {
                return navigator.clipboard.writeText(txt)
                  .then(() => ({ ok: true }))
                  .catch(() => {
                    const ta = Object.assign(document.createElement('textarea'), {
                      value: txt, style: 'position:fixed;left:-9999px;opacity:0',
                    });
                    document.body.appendChild(ta);
                    ta.focus(); ta.select();
                    const ok = document.execCommand('copy');
                    document.body.removeChild(ta);
                    return { ok: !!ok };
                  });
              } else {
                const ta = Object.assign(document.createElement('textarea'), {
                  value: txt, style: 'position:fixed;left:-9999px;opacity:0',
                });
                document.body.appendChild(ta);
                ta.focus(); ta.select();
                const ok = document.execCommand('copy');
                document.body.removeChild(ta);
                return { ok: !!ok };
              }
            } catch (e) {
              return { ok: false, error: String(e) };
            }
          },
          args: [text],
        });

        if (result && typeof result.then === 'function') {
          result.then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, error: String(e) }));
        } else {
          sendResponse(result || { ok: false });
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    })();
    return true; // async
  }
});
